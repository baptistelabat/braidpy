# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""
horn_gear/layout.py
===================

Where everything sits: gear centres, the notches between them, the circles a
carrier rides on, and the columns a braid forms around.

Gears are placed from the connection graph — BFS along the x-axis for a chain,
Kamada-Kawai for anything with a cycle — unless the machine pins its own
geometry, in which case :meth:`~braidpy.horn_gear.model.BraidingMachine
.preferred_layout` wins.  Gear radius goes as sqrt(n_slots), which is a
drawing convention and not a mechanical one — see :func:`_gear_radius`.

Everything else here is derived from those centres: where two gears meet
(:func:`contact_point`), how far out a carrier rides (:func:`carrier_radius`),
how each gear must be turned for its slots to face its notches
(:func:`slot_offsets`), by how much that fails where a line of gears bends
(:func:`offset_residuals`), and how the slots are drawn so that carriers are
handed on without jumping all the same (:func:`slot_angles`).  It is all plain
geometry with no drawing in it, so it can be measured and tested directly.
"""

from __future__ import annotations

import bisect
import math
from collections import deque
from dataclasses import dataclass
from typing import Optional

import networkx as nx
import numpy as np

from .model import Axial, BraidingMachine


def _gear_radius(n_slots: int, scale: float = 1.0) -> float:
    """Drawing radius of a gear with n_slots slots.

    The square root makes the disc *area* proportional to the slot count, so
    every slot is drawn with the same share of its gear — exactly
    ``pi * scale**2`` of area, whatever the gear size.  A radius linear in the
    slot count would give a 16-slot gear four times the radius and sixteen
    times the area of a 4-slot one, which swamps a picture containing both.

    What it does **not** do is keep the slots the same width: the arc per slot
    is ``2 pi scale / sqrt(n_slots)``, so it shrinks as gears grow — 3.14 at
    four slots against 1.11 at thirty-two.  The two properties cannot both
    hold, since constant arc width needs a radius linear in the slot count.

    **This is a convention for drawing, not a kinematic constraint.**  A real
    machine does need a constant slot pitch, because two gears hand a carrier
    over only when a notch of each arrives at the contact together, and equal
    pitch is what keeps them in register; commercial machines sidestep the
    question by giving every gear the same size and usually four slots.
    braidpy does not need it, because a step advances every gear by one slot
    whatever its size and rotation is counted in slots rather than in angle —
    so the radius never enters the simulation.  It decides the picture, and
    through the picture the tangency of :func:`compute_layout` and everything
    derived from it, such as :func:`contact_point` and :func:`carrier_radius`.

    Args:
        n_slots: Number of slots on the gear.
        scale: Global scale factor.

    Returns:
        Radius in layout units.
    """
    return scale * math.sqrt(n_slots)


def compute_layout(
    machine: BraidingMachine,
    scale: float = 1.0,
    seed: int | None = 42,
    iterations: int = 500,
) -> dict[str, tuple[float, float]]:
    """Compute 2-D positions for all gears with adjacent circles exactly tangential.

    For tree / path graphs (flat braid): BFS-based placement along the x-axis
    guarantees every pair of adjacent gear circles touches exactly.

    For cyclic graphs (tubular braid ring): Kamada-Kawai layout with edge
    rest-lengths = r_A + r_B, post-scaled so every edge equals its rest-length
    (valid when all gears have the same radius, i.e. same n_slots).

    Args:
        machine: The BraidingMachine whose gears to position.
        scale: Overall scale factor for gear radii.
        seed: Random seed for reproducibility (cyclic graphs only).
        iterations: Spring-layout iterations (cyclic fallback only).

    Returns:
        Dict mapping gear name → (x, y) in layout coordinates.
    """
    preferred = machine.preferred_layout(scale)
    if preferred is not None:
        return preferred

    if len(machine.gears) == 0:
        return {}
    if len(machine.gears) == 1:
        return {next(iter(machine.gears)): (0.0, 0.0)}

    # ── Tree / path: exact BFS placement ──────────────────────────────────────
    if nx.is_forest(machine.graph):
        return _layout_bfs(machine, scale)

    # ── Cyclic graph: Kamada-Kawai + per-edge exact rescaling ─────────────────
    g = machine.graph.copy()
    for u, v in g.edges():
        r_u = gear_radii(machine, scale)[u]
        r_v = gear_radii(machine, scale)[v]
        g[u][v]["len"] = r_u + r_v

    try:
        raw = nx.kamada_kawai_layout(g, weight="len")
    # Without SciPy (in a browser) or for a graph it cannot lay out, the
    # spring layout instead.
    except Exception:  # noqa: BLE001
        raw = nx.spring_layout(g, seed=seed, iterations=iterations)

    pos = {n: np.array(xy) for n, xy in raw.items()}

    # Rescale so the minimum-ratio edge is exactly its rest-length.
    min_ratio = float("inf")
    for u, v in g.edges():
        actual = float(np.linalg.norm(pos[u] - pos[v]))
        desired = g[u][v]["len"]
        if actual > 1e-9:
            min_ratio = min(min_ratio, desired / actual)

    if math.isfinite(min_ratio) and min_ratio > 0:
        pos = {n: xy * min_ratio for n, xy in pos.items()}

    placed = {n: (float(xy[0]), float(xy[1])) for n, xy in pos.items()}
    return _orient(machine, placed)


def _orient(
    machine: BraidingMachine,
    placed: dict[str, tuple[float, float]],
) -> dict[str, tuple[float, float]]:
    """Settle a ring layout's handedness so it comes out the same every time.

    A graph layout solver is free to hand back a machine or its mirror image,
    and which one it chooses can change with the solver's version.  That is not
    a cosmetic difference here: a machine's connection slots are chosen to face
    its neighbours in a particular layout, so a mirrored one leaves every slot
    pointing at the wrong side and reverses which way its carriers circulate.

    Rings are therefore always laid out running clockwise in screen
    coordinates, by flipping the result when it comes back the other way.  The
    choice is arbitrary, but it has to be made somewhere and the machines'
    connection slots are written against it.
    """
    cycles = nx.cycle_basis(machine.graph)
    if not cycles:
        return placed

    # Walk the ring in a settled order — from its first gear by name, towards
    # whichever of its two neighbours sorts first — so the sign below means the
    # same thing whatever order the cycle was handed back in.
    ring = max(cycles, key=len)
    members = set(ring)
    start = min(ring)
    walk = [start]
    previous = None
    current = start
    while len(walk) < len(ring):
        neighbours = sorted(
            n
            for n in machine.graph.neighbors(current)
            if n in members and n != previous
        )
        if not neighbours:
            return placed
        previous, current = current, neighbours[0]
        walk.append(current)

    area = 0.0
    for i, name in enumerate(walk):
        x1, y1 = placed[name]
        x2, y2 = placed[walk[(i + 1) % len(walk)]]
        area += x1 * y2 - x2 * y1

    if area <= 0:
        return placed
    return {name: (x, -y) for name, (x, y) in placed.items()}


def _spread(back: float | None, n_onward: int) -> list[float]:
    """Directions out of a gear for the gears placed from it.

    The layout grows out from the first gear (:func:`_layout_bfs`): each
    other gear is placed from a neighbour already placed, and ``back`` is
    the direction from the gear to that neighbour, None for the first gear.
    The ``n_onward`` gears placed from it go evenly round it with the way
    back, so one carries straight on and two branch at ±60°; round the
    whole of the first gear, the first to the right."""
    if back is None:
        return [2 * math.pi * i / n_onward for i in range(n_onward)]
    if n_onward == 1:
        # Straight on, the way it came in, to the last bit: a chain stays on
        # the x-axis exactly.
        return [back - math.pi]
    return [back + 2 * math.pi * (i + 1) / (n_onward + 1) for i in range(n_onward)]


def _layout_bfs(
    machine: BraidingMachine,
    scale: float = 1.0,
    directions=None,
) -> dict[str, tuple[float, float]]:
    """Exact tangential layout for tree graphs via BFS.

    The first gear at the origin; then, gear by gear, outwards, each gear's
    neighbours not yet placed round it, each rim touching its own, in the
    directions :func:`_spread` gives — a chain carries straight on along the
    x-axis, a gear with several neighbours onward branches.

    Args:
        machine: The machine, its gears in a tree.
        scale: Overall scale factor.
        directions: How to choose the directions out of a gear for its
            gears placed from it instead: called with the gear, the direction
            back to the neighbour it was placed from (None for the first
            gear) and the neighbours to place from it, it gives a direction
            for each.

    Returns:
        Gear name -> (x, y).
    """
    radii = gear_radii(machine, scale)
    root = next(iter(machine.gears))
    choose = directions or (lambda gear, back, onward: _spread(back, len(onward)))

    pos: dict[str, tuple[float, float]] = {root: (0.0, 0.0)}
    back: dict[str, float | None] = {root: None}
    queue: deque = deque([root])
    while queue:
        gear = queue.popleft()
        onward = sorted(n for n in machine.graph.neighbors(gear) if n not in pos)
        x, y = pos[gear]
        for placed, angle in zip(onward, choose(gear, back[gear], onward)):
            reach = radii[gear] + radii[placed]
            pos[placed] = (x + reach * math.cos(angle), y + reach * math.sin(angle))
            back[placed] = angle + math.pi
            queue.append(placed)
    return pos


def axial_position(
    machine: BraidingMachine,
    layout: dict[str, tuple[float, float]],
    axial: Axial,
) -> tuple[float, float]:
    """Where an axial's column stands: the centroid of the gears it anchors to.

    One gear gives that gear's own centre; a ring of gears gives the centre of
    the hole they enclose.

    Args:
        machine: The machine the axial belongs to.
        layout: Gear centre positions from compute_layout.
        axial: The axial to place.

    Returns:
        (x, y) of the column in layout coordinates.
    """
    xs = [layout[name][0] for name in axial.anchor]
    ys = [layout[name][1] for name in axial.anchor]
    return sum(xs) / len(xs), sum(ys) / len(ys)


def axial_positions(
    machine: BraidingMachine,
    layout: dict[str, tuple[float, float]],
) -> dict[str, tuple[float, float]]:
    """Column position for every axial on the machine, keyed by axial name."""
    return {a.name: axial_position(machine, layout, a) for a in machine.axials}


def axial_clearance(
    machine: BraidingMachine,
    layout: dict[str, tuple[float, float]],
    position: tuple[float, float],
    scale: float = 1.0,
) -> float:
    """Free space around a column: the distance to the nearest carrier path.

    Carriers on a gear ride that gear's rim, so the distance from a point to
    the nearest carrier is ``|distance to the centre - radius|``, minimised
    over every gear.  The one expression covers both anchors: a column at a
    gear's centre clears that gear's radius, while a column in a tube clears
    the gap between the hole's centre and the surrounding rims.

    A value at or below zero means carriers pass through the column in this
    projection.  That is a genuine clash for a tube core, but expected for a
    flat braid, whose core rises through the convergence point where the
    carriers meet.

    Args:
        machine: The machine.
        layout: Gear centre positions from compute_layout.
        position: The column's (x, y).
        scale: Scale factor (must match the one used for the layout).

    Returns:
        Clearance in layout units.
    """
    px, py = position
    radii = gear_radii(machine, scale)
    return min(
        abs(math.hypot(layout[name][0] - px, layout[name][1] - py) - radii[name])
        for name in machine.gears
    )


def contact_point(
    machine: BraidingMachine,
    layout: dict[str, tuple[float, float]],
    gear: str,
    neighbor: str,
    scale: float = 1.0,
) -> tuple[float, float]:
    """The middle of the notch two gears share.

    Where the circles cross, the notch is the chord between the two crossings
    and the bobbin sits at its middle — which lies on the line between the two
    centres.  Where the circles merely touch, the two crossings coincide and
    that middle is the tangent point, so one construction serves both.
    """
    cx, cy = layout[gear]
    nx_, ny_ = layout[neighbor]
    dx, dy = nx_ - cx, ny_ - cy
    dist = math.hypot(dx, dy) or 1.0

    radii = gear_radii(machine, scale)
    along = (dist**2 + radii[gear] ** 2 - radii[neighbor] ** 2) / (2 * dist)
    return cx + along * dx / dist, cy + along * dy / dist


def contact_angle(
    machine: BraidingMachine,
    layout: dict[str, tuple[float, float]],
    gear: str,
    neighbor: str,
    scale: float = 1.0,
) -> float:
    """Angle (rad) from a gear's centre toward the notch it shares with a neighbour."""
    cx, cy = layout[gear]
    px, py = contact_point(machine, layout, gear, neighbor, scale)
    return math.atan2(py - cy, px - cx)


def carrier_radius(
    machine: BraidingMachine,
    layout: dict[str, tuple[float, float]],
    gear: str,
    scale: float = 1.0,
) -> float:
    """How far from a gear's centre its bobbins ride.

    A bobbin sits *in* a notch, so it turns about the gear at the distance of
    that notch — the gear's own radius when the gears merely touch, and less
    than that when they overlap and the notch is cut back inside the rim.
    """
    radius = gear_radii(machine, scale)[gear]
    contacts = machine.connections_of(gear)
    if not contacts or not machine.gears_interpenetrate:
        # Gears that only touch carry their bobbins on the rim.  Saying so
        # outright keeps them exactly there, rather than a fraction off it
        # because a numerically solved layout left the circles a hair apart.
        return radius

    cx, cy = layout[gear]
    distances = [
        math.dist(
            (cx, cy),
            contact_point(
                machine,
                layout,
                gear,
                conn.gear_b if conn.gear_a == gear else conn.gear_a,
                scale,
            ),
        )
        for conn in contacts
    ]
    return sum(distances) / len(distances)


def _contacts(
    machine: BraidingMachine,
    layout: dict[str, tuple[float, float]],
) -> dict[str, list[tuple[float, float]]]:
    """Per gear, each of its contacts: the angle on the gear of the slot that
    is there at every step, ``2π*slot0/N``, and the contact's angle on the
    deck, seen from the gear's centre."""
    contacts: dict[str, list[tuple[float, float]]] = {
        name: [] for name in machine.gears
    }
    for conn in machine.connections:
        for gname, other, slot0 in [
            (conn.gear_a, conn.gear_b, conn.slot_a0),
            (conn.gear_b, conn.gear_a, conn.slot_b0),
        ]:
            gear = machine.gears[gname]
            contacts[gname].append(
                (
                    2 * math.pi * slot0 / gear.n_slots,
                    contact_angle(machine, layout, gname, other),
                )
            )
    return contacts


def _gear_constraints(
    machine: BraidingMachine,
    layout: dict[str, tuple[float, float]],
) -> dict[str, list[float]]:
    """Per gear, the rotation offset each of its connections asks for.

    A connection ``gear_a[slot_a0] ↔ gear_b[slot_b0]`` wants slot ``slot_a0`` of
    gear_a to point at gear_b, i.e. ``phi_a = theta_ab - 2π*slot_a0/N_a``.  A
    gear with several connections gets one such value per connection; they all
    agree only when the connection slots match the physical layout.
    """
    return {
        name: [theta - slot for slot, theta in contacts]
        for name, contacts in _contacts(machine, layout).items()
    }


def slot_offsets(
    machine: BraidingMachine,
    layout: dict[str, tuple[float, float]],
) -> dict[str, float]:
    """Per-gear rotation offset phi so connection slots point toward their neighbors.

    Every connection of a gear is taken into account, via the circular mean of
    the offsets they each ask for.  When the machine's connection slots match
    its layout the requests coincide and the mean reproduces them exactly; when
    they do not, the residual error is shared between the contacts instead of
    being dumped entirely onto whichever connection happened to come second.
    """
    offsets: dict[str, float] = {}
    for name, wanted in _gear_constraints(machine, layout).items():
        if not wanted:
            offsets[name] = 0.0
            continue
        sin_sum = sum(math.sin(a) for a in wanted)
        cos_sum = sum(math.cos(a) for a in wanted)
        # Degenerate: requests cancel out (e.g. exactly opposed).  The mean is
        # meaningless there, so honour the first connection rather than spin.
        if math.hypot(sin_sum, cos_sum) < 1e-9:
            offsets[name] = wanted[0]
        else:
            offsets[name] = math.atan2(sin_sum, cos_sum)
    return offsets


def offset_residuals(
    machine: BraidingMachine,
    layout: dict[str, tuple[float, float]],
) -> dict[str, float]:
    """Worst angular error (radians) between each gear's slots and its contacts.

    Zero means every contact of that gear falls exactly on a slot.  A non-zero
    value means its slots, turned rigidly, cannot meet every contact, as where
    a line of gears bends; :class:`GearAngles` then draws them spread
    unevenly, so that carriers do not jump when they transfer there.
    """
    offsets = slot_offsets(machine, layout)
    residuals: dict[str, float] = {}
    for name, wanted in _gear_constraints(machine, layout).items():
        phi = offsets[name]
        residuals[name] = max(
            (abs((a - phi + math.pi) % (2 * math.pi) - math.pi) for a in wanted),
            default=0.0,
        )
    return residuals


#: How far (radians) a gear's slots may miss its contacts and still be drawn
#: turned rigidly: rounding, not a bend.
FITS = 1e-9


@dataclass(frozen=True)
class GearAngles:
    """Where a gear's slots are drawn on the deck, from their angle on the gear.

    A gear's slots are evenly spaced round it and turn at its rate, and are
    drawn turned by its offset (:func:`slot_offsets`).  That puts a slot on
    every contact at every step only when the contacts are a whole number of
    slots apart round the gear, as on a straight line of gears.  Where a line
    bends at a gear they are not, so its slots are drawn spread unevenly
    instead: the slot at a contact is always drawn on it, and those between
    two contacts evenly between their angles.  A carrier rounds the outside of
    the bend a little faster than the inside, then, and is handed on where it
    is, without jumping.  Which slot is where is the machine's; only the
    drawing changes (see :func:`offset_residuals`).

    Args:
        offset: The gear's offset, from :func:`slot_offsets`.
        knots: Each contact as (angle of its slot on the gear, angle on the
            deck), in order round the gear; empty where turning the slots
            rigidly by ``offset`` puts one on every contact.
    """

    offset: float
    knots: tuple[tuple[float, float], ...] = ()

    def __call__(self, angle: float) -> float:
        """The angle on the deck of a slot at ``angle`` on the gear."""
        if len(self.knots) < 2:
            return self.offset + angle
        turn = 2 * math.pi
        # Where on the gear, in [0, 2π): rounding can carry ``%`` to 2π.
        angle %= turn
        if angle >= turn:
            angle = 0.0
        # The last knot at or before it, the one before the first if none is.
        k = bisect.bisect_right([slot for slot, _ in self.knots], angle) - 1
        here, at = self.knots[k]
        there, to = self.knots[(k + 1) % len(self.knots)]
        span = (there - here) % turn or turn
        return at + ((to - at) % turn or turn) * ((angle - here) % turn) / span


def slot_angles(
    machine: BraidingMachine,
    layout: dict[str, tuple[float, float]],
) -> dict[str, GearAngles]:
    """How each gear's slots are drawn: see :class:`GearAngles`.

    Args:
        machine: The machine definition.
        layout: Gear centres, from :func:`compute_layout`.

    Returns:
        Gear name -> its :class:`GearAngles`.
    """
    offsets = slot_offsets(machine, layout)
    residuals = offset_residuals(machine, layout)
    angles = {}
    for name, contacts in _contacts(machine, layout).items():
        if residuals[name] <= FITS:
            angles[name] = GearAngles(offsets[name])
            continue
        # One knot a slot: two contacts on one slot are one point.
        knots = dict(sorted(contacts))
        angles[name] = GearAngles(offsets[name], tuple(knots.items()))
    return angles


def _signed_area(
    face: list[str],
    layout: dict[str, tuple[float, float]],
) -> float:
    """Shoelace area of a face's polygon; sign gives its winding direction."""
    total = 0.0
    for i, name in enumerate(face):
        x1, y1 = layout[name]
        x2, y2 = layout[face[(i + 1) % len(face)]]
        total += x1 * y2 - x2 * y1
    return total / 2


def tube_rings(
    machine: BraidingMachine,
    layout: Optional[dict[str, tuple[float, float]]] = None,
) -> list[list[str]]:
    """Find the rings of gears that enclose a hole — one per tube.

    Gears are tangent circles in the plane, so the connection graph is planar
    and the holes in the machine are exactly the *bounded faces* of its planar
    embedding.  Every face is walked and the outer one — the space around the
    machine rather than a hole inside it — is dropped, being the largest by
    absolute signed area.

    A flat braid has no cycle and so returns no rings; a ring braid returns
    one; a grid of gears returns one per opening.

    Args:
        machine: The machine to inspect.
        layout: Gear centre positions (computed if None).

    Returns:
        List of rings, each a list of gear names in the order they enclose
        the hole.  Empty if the machine has no hole.
    """
    if layout is None:
        layout = compute_layout(machine)

    is_planar, embedding = nx.check_planarity(machine.graph)
    if not is_planar:
        return []

    seen: set = set()
    found: list[list[str]] = []
    for u, v in embedding.edges():
        if (u, v) in seen:
            continue
        face = embedding.traverse_face(u, v, mark_half_edges=seen)
        if len(face) >= 3:
            found.append(list(face))

    if not found:
        return []
    outer = max(found, key=lambda f: abs(_signed_area(f, layout)))
    return [f for f in found if f is not outer]


def tube_axials(
    machine: BraidingMachine,
    layout: Optional[dict[str, tuple[float, float]]] = None,
    min_clearance: float = 1e-6,
    prefix: str = "core",
) -> list[Axial]:
    """One core Axial per tube the machine braids.

    Rings too tight to hold a core — where the surrounding gears reach the
    centre of the hole — are skipped rather than returned, so the result is
    only cores that physically fit.

    Args:
        machine: The machine to inspect.
        layout: Gear centre positions (computed if None).
        min_clearance: Smallest acceptable gap between core and carriers.
        prefix: Name stem; cores are named ``core``, ``core_1``, … in order.

    Returns:
        List of Axial, empty for a machine with no tube.
    """
    if layout is None:
        layout = compute_layout(machine)

    axials: list[Axial] = []
    for ring in tube_rings(machine, layout):
        candidate = Axial(name=prefix, anchor=tuple(ring))
        position = axial_position(machine, layout, candidate)
        if axial_clearance(machine, layout, position) < min_clearance:
            continue
        name = prefix if not axials else f"{prefix}_{len(axials)}"
        axials.append(Axial(name=name, anchor=tuple(ring)))
    return axials


# Gear centres as many decimals alike as this are one axle: a split gear's
# parts, placed on it by the same sums.
_CENTRE_DIGITS = 9


def _axle(layout: dict[str, tuple[float, float]], name: str) -> tuple[float, float]:
    """The axle a gear turns on, the same for a split gear's parts."""
    x, y = layout[name]
    return round(x, _CENTRE_DIGITS), round(y, _CENTRE_DIGITS)


def axial_spots(
    machine: BraidingMachine,
    layout: Optional[dict[str, tuple[float, float]]] = None,
) -> list[Axial]:
    """Every place the machine could feed an axial yarn, loaded or not.

    Up each gear's hollow spindle, at its centre — once for the parts of a
    split gear, which share an axle, named by its first part — and down the
    hole of each ring of gears that leaves room for one (:func:`tube_axials`).
    Which of them a machine braids round is its :attr:`~braidpy.horn_gear
    .model.BraidingMachine.axials`.

    Args:
        machine: The machine to inspect.
        layout: Gear centre positions (computed if None).

    Returns:
        The gears' spots, in the machine's order, then the rings'.
    """
    if layout is None:
        layout = compute_layout(machine)
    spots: list[Axial] = []
    centres: set[tuple[float, float]] = set()
    for name in machine.gears:
        centre = _axle(layout, name)
        if centre in centres:
            continue
        centres.add(centre)
        spots.append(Axial(f"axial_{name}", (name,)))
    return spots + tube_axials(machine, layout)


def ring_core(
    machine: BraidingMachine,
    layout: Optional[dict[str, tuple[float, float]]] = None,
) -> Axial | None:
    """The core a machine that is one ring of gears braids round: down the
    hole the ring encloses, as a tubular machine's or a lace machine's.

    Only a ring of every gear makes a tube: a line folded round, as the
    multiband machine's, encloses a hole between its gears too, but braids
    flat bands, not round it.

    Args:
        machine: The machine.
        layout: Gear centre positions (computed if None).

    Returns:
        The core, named ``centre``; None if the machine is not one ring, or
        its hole has no room for a core.
    """
    for core in tube_axials(machine, layout, prefix="centre"):
        if set(core.anchor) == set(machine.gears):
            return core
    return None


def gear_radii(machine: BraidingMachine, scale: float = 1.0) -> dict[str, float]:
    """Return the visual radius for each gear.

    Args:
        machine: The BraidingMachine.
        scale: Scale factor.

    Returns:
        Dict mapping gear name → radius.
    """
    return {
        name: _gear_radius(gear.size or gear.n_slots, scale)
        for name, gear in machine.gears.items()
    }


def carrier_xy(
    machine: BraidingMachine,
    layout: dict[str, tuple[float, float]],
    angles: dict[str, GearAngles],
    carrier_radii: dict[str, float],
    position: tuple[str, int],
    time: int,
    frac: float = 0.0,
) -> tuple[float, float]:
    """Where in the plane a carrier is, at continuous time ``time + frac``.

    A carrier rides in a horn of its gear, so its angle is simply that slot's
    angle: it turns with the gear and always sits on its slot, drawn where
    :class:`GearAngles` draws it.
    It is drawn on whatever is actually moving it this step — on a machine
    with shared slots that is the receiving gear, see
    :meth:`~braidpy.horn_gear.model.BraidingMachine.riding_position`.

    Transfers stay continuous without any special casing: a carrier moves to
    the neighbour only at the step where its slot is at the contact point, and
    it lands on the neighbour's slot that is at that same contact point at that
    same instant, so the two coincide; where a line bends at a gear, its
    slots are drawn so that they still do (:class:`GearAngles`).

    Args:
        machine: The machine definition.
        layout: Gear centres, from :func:`compute_layout`.
        angles: How each gear's slots are drawn, from :func:`slot_angles`.
        carrier_radii: Per-gear riding radius, from :func:`carrier_radius`.
        position: The carrier's recorded (gear, slot) at ``time``.
        time: The step being taken.
        frac: How far into that step, from 0 to 1.

    Returns:
        The carrier's (x, y).
    """
    gear_name, slot = machine.riding_position(position, time)
    cx, cy = layout[gear_name]
    r = carrier_radii[gear_name]
    ang = angles[gear_name](machine.slot_angle(gear_name, slot, time, frac))
    return cx + r * math.cos(ang), cy + r * math.sin(ang)
