# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""The braid itself (:class:`Braid`): a word in Artin's generators on so
many strands, and what can be done with it.
"""

import enum
from collections.abc import Sequence
from typing import TYPE_CHECKING, Optional, cast

import numpy as np

if TYPE_CHECKING:
    # sympy is only needed for the Burau matrices, and is slow to import —
    # seconds, in a browser: imported there, when they are asked for.
    from sympy import Matrix
from dataclasses import dataclass, field

from braidpy.garside_canonical_form import GarsideCanonicalFactors
from braidpy.parametric_strand import (
    Arc,
    ParametricStrand,
    combine_arcs,
    make_arc,
    make_idle_arc,
)
from braidpy.utils import (
    StrictlyPositiveInt,
    colorize,
    int_to_subscript,
    int_to_superscript,
    lazy_module,
)

if TYPE_CHECKING:
    import math_braid
else:
    # It imports sympy, slow to import: only when braids are compared.
    math_braid = lazy_module("math_braid")
from collections.abc import Iterable


def reduced_burau_generator(generator: int, n_strands: int, t, one, zero) -> list[list]:
    """The reduced Burau matrix of one generator, σ_i or its inverse, as
    rows: the identity, but for row i (from 0),

        σ_i:   ( …, t, −t, 1, … )    at columns i − 1, i, i + 1,
        σ_i⁻¹: ( …, 1, −1/t, 1/t, … ),

    the columns that fall off the matrix left out.  ``t``, ``one`` and
    ``zero`` are of whatever ring the matrix is wanted in: a sympy symbol,
    an element of a polynomial field, a complex number.

    Args:
        generator: ``i`` for σ_i, ``-i`` for its inverse.
        n_strands: Number of strands; the matrix is ``n_strands − 1`` square.
        t: The Burau variable.
        one: The ring's one.
        zero: The ring's zero.

    Returns:
        The rows.
    """
    m = n_strands - 1
    i = abs(generator) - 1
    rows = [[one if r == c else zero for c in range(m)] for r in range(m)]
    if generator > 0:
        left, middle, right = t, -t, one
    else:
        left, middle, right = one, -one / t, one / t
    if i >= 1:
        rows[i][i - 1] = left
    rows[i][i] = middle
    if i <= m - 2:
        rows[i][i + 1] = right
    return rows


# How long handle reduction is given to say whether a braid is trivial,
# before math_braid's normal form decides instead (Braid.is_trivial).
HANDLE_REDUCTION_S = 5.0

# Define a type alias for clarity
SignedCrossingIndex = int
BraidingStep = SignedCrossingIndex | tuple[SignedCrossingIndex, ...]
BraidingProcess = tuple[BraidingStep, ...]


class BraidWordNotation(str, enum.Enum):
    """How :meth:`Braid.format_to_notation` writes a braid word: in Artin's generators
    (``s_{1}^{1.0}``), in letters (``aB``), or as math-braid and braidlab
    write it (``<1 : -2>``)."""

    ARTIN = "ARTIN"
    ALPHA = "ALPHA"
    DEFAULT = "DEFAULT"


def single_crossing_braiding_process(
    process: BraidingProcess,
) -> list[SignedCrossingIndex]:
    """
    Flattens a tuple of braiding steps into a list of signed crossings.

    Each step may be a single crossing or multiple simultaneous crossings.
    To get Artin generators we need only consecutive single crossing, which is topologically equivalent
    """
    sequential_single_crossings_index: list[SignedCrossingIndex] = []
    for step in process:
        if isinstance(step, Iterable):
            sequential_single_crossings_index.extend(step)
        else:
            sequential_single_crossings_index.append(
                int(step)
            )  # Force int type to be able to use with math_braid
    return sequential_single_crossings_index


# Recursive type for nested sequences of integers
BraidProcess = int | Sequence["BraidProcess"]


@dataclass(frozen=True)
class Braid:
    """
    Sometimes referred to as algebraic braids
    Args:
        process (BraidProcess): list of Artin's generator, which may group or not by parenthesis (tuples)
        n_strands (Optional[int]): number of strands. Default to the minimum number needed for process
    """

    process: BraidProcess
    # None until __post_init__ infers it; an int on every braid made.
    n_strands: int = field(default=None)  # type: ignore[assignment]

    def __post_init__(self):
        # Hack to allow to code single generator without parenthesis
        if isinstance(self.process, Iterable):
            process = self.process
        else:
            process = (self.process,)
            object.__setattr__(self, "process", (self.process,))

        sequential_generators = single_crossing_braiding_process(process)
        # Infer number of strands if not provided
        inferred_n = (
            abs(max(sequential_generators, key=abs)) + 1 if sequential_generators else 1
        )
        actual_n = self.n_strands if self.n_strands is not None else inferred_n

        # Validate generators
        if any(abs(g) >= actual_n for g in sequential_generators):
            raise ValueError(f"Generator index out of bounds for {actual_n} strands")

        # Set the inferred value if needed (bypass frozen with object.__setattr__)
        if self.n_strands is None:
            object.__setattr__(self, "n_strands", actual_n)

    @property
    def generators(self) -> list[int]:
        """List of Artin's generators in the braid word."""
        # Checked to be a braiding process when the braid was made.
        return single_crossing_braiding_process(cast(BraidingProcess, self.process))

    @property
    def main_generator(self) -> int | None:
        """A main generator of a braid word w is the generator with the lowest index.

        https://pure.tue.nl/ws/portalfiles/portal/67742824/630595-1.pdf page 33
        """
        if not self.no_zero().generators:
            return None
        return min([abs(gen) for gen in self.generators if abs(gen) > 0])

    def __repr__(self) -> str:
        return f"Braid({self.generators}, n_strands={self.n_strands})"

    def format_to_notation(self, target: str = "") -> str:
        """
        Inspired from https://github.com/abhikpal/dehornoy/blob/master/braid.py

        Allow to format the braidword using several classical notations.:

        The Artin representation can also be used in a latex file.

        The neutral element is 'e' for the Artin representation and '#' for alpha.

        Args:
            target(str): Among
                'alpha': for example 'aBa'
                'artin'  for example 's_{1}^{1.0} s_{2}^{1.0} s_{1}^{-1.0} s_{2}^{-1.0}'
                'default' syntax used by other tools such as math-braid and braidlab

        Returns:
            str: the formatted braid word
        """
        match target.upper():
            case BraidWordNotation.ARTIN.value:
                if len(self.generators) == 0:
                    return "e"
                return " ".join(
                    "s_{" + str(abs(g)) + "}^{" + str(abs(g) / g) + "}"
                    if g != 0
                    else "e"
                    for g in self.generators
                )
            case BraidWordNotation.ALPHA.value:
                if len(self.generators) == 0:
                    return "#"

                def alp(g):
                    return chr(ord("Q") + int(abs(g) / g) * 16 + abs(g) - 1)

                return "".join(alp(g) if g != 0 else "#" for g in self.generators)
            case BraidWordNotation.DEFAULT.value | "":
                """
                This is the syntax used by math-braid and braidlab
                """
                return "<" + " : ".join(str(g) for g in self.generators) + ">"
            case _:
                raise NotImplementedError(
                    f"target notation should be among {[notation.value for notation in BraidWordNotation]}"
                )

    def format(
        self,
        generator_symbols: Optional[list[str]] = None,
        inverse_generator_symbols: Optional[list[str]] = None,
        zero_symbol: str = "e",
        separator: str = "",
    ) -> str:
        """
        Allow to format the braid word following different formats.

        Note that the power are limited to -1/1 due to the actual braid word definition (not possible to display σ₁² for example)

        See also format_to_notation for simpler predefined format

        Args:
            generator_symbols (Optional(list[str])): Default to ["σ₁", "σ₂", ...]
            inverse_generator_symbols(Optional(list[str])): Default to ["σ₁⁻¹", ...]
            zero_symbol (Optional(str)): Default to "e
            separator(Optional(str)): Default to ""

        Returns:
            str: the formatted braid word
        """
        if generator_symbols is None:
            generator_symbols = [
                "σ" + int_to_subscript(i + 1) for i in range(self.n_strands)
            ]
        if inverse_generator_symbols is None:
            inverse_generator_symbols = [
                "σ" + int_to_subscript(i + 1) + int_to_superscript(-1)
                for i in range(self.n_strands)
            ]

        word = ""
        for i, gen in enumerate(self.generators):
            if gen > 0:
                word = word + generator_symbols[gen - 1]
            elif gen < 0:
                word = word + inverse_generator_symbols[-gen - 1]
            else:
                word = word + zero_symbol
            if i < len(self.generators) - 1:
                word += separator
        return f"{word}"

    def no_zero(self) -> "Braid":
        """Suppress all the zero steps (multiplication by neutral element).

        Returns:
            Braid: A new braid with zero generators removed.
        """
        return Braid([g for g in self.generators if g != 0], self.n_strands)

    def word_length(self) -> int:
        """Length of the word including neutral element.

        Returns:
            int: The length of the braid word.
        """
        return len(self.generators)

    def __len__(self) -> int:
        """Define the length of the braid as the length of its word.

        Returns:
            int: The length of the braid word.
        """
        return self.word_length()

    def __mul__(self, other: "Braid") -> "Braid":
        """Compose two braids (concatenate operation of other after self).

        This corresponds to multiplication of two braids in braid theory.

        Args:
            other: The braid to compose with self.

        Returns:
            Braid: The composed braid.

        Raises:
            ValueError: If braids have different number of strands.
        """
        if self.n_strands != other.n_strands:
            raise ValueError("Braids must have the same number of strands")
        return Braid(self.generators + other.generators, self.n_strands)

    def __pow__(self, n: int) -> "Braid":
        """Raise braid to a power by concatenating it n times.

        Args:
            n: The exponent.

        Returns:
            Braid: The braid raised to power n.
        """
        if n == 0:
            return Braid([], self.n_strands)
        elif n > 0:
            result = self
            for _ in range(n - 1):
                result = result * self
            return result
        else:
            return (self ** (-n)).inverse()

    def __key(self) -> tuple:
        """Get a key on the braid (used by hash function).

        Returns:
            tuple: Key constructed with the Artin's generators and the number of strands.
        """
        return tuple(self.generators + [self.n_strands])

    def word_eq(self, other: "Braid") -> bool:
        """Check if two braids have identical word representations.

        Args:
            other: The braid to compare with.

        Returns:
            bool: True if the braid words are identical.
        """
        return self.__key() == other.__key()

    def __hash__(self) -> int:
        """Hash the braid based on its word representation.

        Returns:
            int: Hash value for the braid.
        """
        return hash(self.__key())

    def __eq__(self, other: object) -> bool:
        """Check if two braids are topologically equivalent: the same braid,
        however their words are written.

        By Dehornoy's handle reduction (:mod:`braidpy.handles_reduction`):
        two braids are the same exactly when one followed by the other's
        inverse is trivial (:meth:`is_trivial`, which falls back on
        math_braid's normal form for the rare braids handle reduction is slow
        on).  PATRICK DEHORNOY AND BERT WIEST, "On word reversing in braid groups",
        https://dehornoy.lmno.cnrs.fr/Papers/Dhg.pdf

        Args:
            other: The braid to compare with.

        Returns:
            bool: True if the braids are topologically equivalent.
        """
        if not isinstance(other, Braid):
            return NotImplemented
        if self.n_strands != other.n_strands:
            return False
        return (self * other.inverse()).is_trivial()

    def inverse(self) -> "Braid":
        """Return the inverse of the braid.

        This corresponds to the image of the braid in a mirror.
        Both order and signs are reversed.

        Returns:
            Braid: The inverse braid.
        """
        return Braid([-g for g in reversed(self.generators)], self.n_strands)

    def __invert__(self) -> "Braid":
        """Inverse of the braid with symbol ~.

        This corresponds to the image of the braid in a mirror orthogonal to
        the braid direction. The last operation becomes the first one.
        Both order of operation and signs are reversed, but not order of strands.

        Example:
            >>> x = Braid([1, -2], 3)
            >>> ~x

        Returns:
            Braid: The inverse braid.
        """
        return self.inverse()

    def n(self, n_strands: int) -> "Braid":
        """Compact notation to allow changing the number of strands.

        Args:
            n_strands: The new number of strands.

        Returns:
            Braid: A new braid with updated number of strands.
        """
        return Braid(self.process, n_strands)

    def flip(self) -> "Braid":
        """
        Flip the braid
        This corresponds to the image of the braid in a mirror on the side of the braid reordered from left to right
        The strands are reversed, not the order of operations
        Sign is also changed.
        This step is often used when braiding

        Example:
            >>> b = Braid([1], 3)
            >>> basic_3_braid = (b * (b.flip())) ** 3

        Returns:
            Braid: The reversed braid.
        """
        gen = [-np.sign(g) * (self.n_strands - abs(g)) for g in self.generators]
        return Braid(gen, self.n_strands)

    def half_twist(self, sign: int = +1) -> "Braid":
        """Twist the braid with half a turn.

        https://en.wikipedia.org/wiki/Twist_(differential_geometry)

        Args:
            sign: Sign of the twist. If positive the first strand is going over.
                Defaults to +1.

        Returns:
            Braid: The twisted braid.
        """
        b = self
        for i in range(abs(self.n_strands)):
            b = b * (
                slide_strand(
                    start_index=1, n_slide=self.n_strands - i - 1, sign=np.sign(sign)
                ).n(self.n_strands)
            )
        return b

    def full_twist(self, sign: int = +1) -> "Braid":
        """Twist the braid with a complete turn.

        https://en.wikipedia.org/wiki/Twist_(differential_geometry)

        Args:
            sign: Sign of the twist. If positive the first strand is going over.
                Defaults to +1.

        Returns:
            Braid: The twisted braid.
        """
        return self.half_twist(sign=sign).half_twist(sign=sign)

    def full_twists(self) -> int:
        """How many whole turns of every strand together the braid contains.

        The full twist Δ² commutes with every braid, so it can always be
        moved to the front: β = Δ^{2m} · β′.  Which ``m`` is a choice, made
        here so that what is left sits evenly about no twist at all: the
        canonical factors give the least and the most twist the braid lies
        between (its infimum and supremum, in half twists), and ``m`` is
        their middle in whole turns, rounded to the nearest.  Adding ``k``
        full twists to any braid adds exactly ``k`` to it.

        A real braid hanging free, as from a kumihimo disk, does not keep
        these: turning every strand together only turns the cord, which
        turns back.  See :meth:`without_full_twists`.

        Returns:
            int: ``m``, negative for turns the other way.
        """
        if not self.n_strands or not self.no_zero().generators:
            return 0
        factors = self.get_canonical_factors()
        least = factors.n_half_twist
        most = least + len(factors.Ai)
        # Half twists, two to a turn.
        return int(np.floor((least + most) / 4 + 0.5))

    def without_full_twists(self) -> "Braid":
        """The braid with its whole turns taken out: β · Δ^{-2m}.

        What is left is the braid's real crossings, and at most a fraction of
        a turn.  Two braids that differ only by full twists — a word read
        off a kumihimo disk that was turned round, and the cord it makes —
        are then equal.

        Returns:
            Braid: the same crossings, without the full twists.
        """
        m = self.full_twists()
        b = self
        for _ in range(abs(m)):
            b = b.full_twist(sign=-1 if m > 0 else 1)
        return b

    def up_side_down(self) -> "Braid":
        """Invert up and down crossing operations.

        For hair braiding this is called "inversé".

        Returns:
            Braid: The mirrored braid.
        """
        gen = [-g for g in self.generators]
        return Braid(gen, self.n_strands)

    def __neg__(self) -> "Braid":
        """Invert up and down crossing operations.

        Returns:
            Braid: The mirrored braid.
        """
        return self.up_side_down()

    def is_reduced(self) -> bool:
        """Check if a braid word is reduced.

        A braid word w is reduced either if it is the null string, or the empty
        braid, or if the main generator of w occurs only positively or only
        negatively.

        https://pure.tue.nl/ws/portalfiles/portal/67742824/630595-1.pdf page 33

        Returns:
            bool: True if the braid word is reduced.
        """
        if not self.generators:
            return True
        mg = self.main_generator
        signs = [g > 0 for g in self.generators if abs(g) == mg]
        return all(signs) or not any(signs)

    def writhe(self) -> int:
        """Calculate the writhe of the braid (sum of generator powers).

        Returns:
            int: The writhe value.
        """
        return int(sum(np.sign(self.generators)))

    def get_canonical_factors(self) -> GarsideCanonicalFactors:
        """
        Get decomposition in Artin's left normal form, Δ^k · A_1 ⋯ A_r

        ``n_half_twist`` is ``k``, the number of half twists Δ in front, and
        each ``A_i`` is a permutation braid — a positive braid in which any
        two strands cross at most once — given as the permutation it makes.
        See :func:`~braidpy.garside_canonical_form.artin_left_normal_form`.

        Returns:
            GarsideCanonicalFactors: the unique decomposition of the braid according to left convention
        """
        from braidpy.garside_canonical_form import artin_left_normal_form

        n = StrictlyPositiveInt(self.n_strands)
        k, factors = artin_left_normal_form(self.generators, n)
        return GarsideCanonicalFactors(n_half_twist=k, n_strands=n, Ai=factors)

    def get_band_canonical_factors(self) -> GarsideCanonicalFactors:
        """
        Get decomposition in the Birman–Ko–Lee (band generator) left normal form

        Relies on math_braid implementation from J. Cha et al, "An Efficient Implementation of Braid Groups",
        Advances in Cryptology: Proceedings of ASIACRYPT 2001,
        Lecture Notes in Computer Science (2001), 144--156.
        https://www.iacr.org/archive/asiacrypt2001/22480144.pdf

        Not Artin's form: the twist in front is the band generators' δ, a
        ``1/n_strands`` turn of every strand together, so ``n_half_twist``
        here counts those rather than half twists — a full twist is
        ``n_strands`` of them — and the factors are math_braid's.

        Returns:
            GarsideCanonicalFactors: the band generator decomposition
        """
        br = self.no_zero()
        if br.generators:
            b = math_braid.Braid(list(self.generators), self.n_strands)
            b.cleanUpFactors()
            return GarsideCanonicalFactors(n_half_twist=b.p, n_strands=b.n, Ai=b.a)
        else:
            return GarsideCanonicalFactors(
                n_half_twist=0, n_strands=StrictlyPositiveInt(br.n_strands), Ai=()
            )

    def to_matrix(self) -> "Matrix":
        """Convert braid to its (unreduced) Burau matrix representation.

        Burau matrix representation is faithful for n_strands=3 or n_strands=4,
        but not faithful for n_strand>=5.
        https://arxiv.org/abs/2607.05283

        Returns:
            Matrix: The Burau matrix representation of the braid.
        """
        from sympy import eye, symbols

        t = symbols("t")
        matrix = eye(self.n_strands)
        for gen in self.generators:
            i = abs(gen) - 1
            mat = eye(self.n_strands)
            if gen > 0:
                # σ_i
                mat[i, i] = 1 - t
                mat[i, i + 1] = t
                mat[i + 1, i] = 1
                mat[i + 1, i + 1] = 0
            if gen < 0:
                # σ_i⁻¹
                mat[i, i] = 0
                mat[i, i + 1] = 1
                mat[i + 1, i] = t**-1
                mat[i + 1, i + 1] = 1 - t**-1
            matrix = matrix * mat  # Correct order: left-to-right
        return matrix

    def to_reduced_matrix(self) -> "Matrix":
        """Return the reduced Burau representation.

        https://en.wikipedia.org/wiki/Burau_representation

        Returns:
            Matrix: The reduced Burau matrix representation.
        """
        from sympy import Matrix, eye, symbols

        t = symbols("t")
        matrix = eye(self.n_strands - 1)
        for gen in self.generators:
            # Correct order: left-to-right
            matrix = matrix * Matrix(
                reduced_burau_generator(gen, self.n_strands, t, 1, 0)
            )
        return matrix

    def is_trivial(self) -> bool:
        """Check if the braid is trivial (identity braid): no crossing at
        all, however its word is written (``σ₁σ₁⁻¹`` is trivial).

        By Dehornoy's handle reduction (:mod:`braidpy.handles_reduction`): a
        braid is trivial exactly when its Dehornoy sign is 0.  It is the
        faster on most braids, several times faster than math_braid's normal
        form; but it can blow up on long words of many strands (ABOK #3082's,
        61 strands and 2400 crossings: five minutes, where math_braid takes
        half a minute).  So it is given ``HANDLE_REDUCTION_S`` seconds, and
        math_braid's normal form decides if it has not.

        Returns:
            bool: True if the braid is trivial.
        """
        # Here: handles_reduction itself imports this module.
        from braidpy.handles_reduction import (
            HandleReducedButUnexpectedResult,
            HandleReductionMode,
            dehornoy_reduce_core,
        )

        crossings = self.no_zero().generators
        if not crossings:
            return True
        try:
            reduced = dehornoy_reduce_core(
                crossings, HandleReductionMode.COMPARE, time_out_s=HANDLE_REDUCTION_S
            )
        except HandleReducedButUnexpectedResult:
            return not math_braid.Braid(list(crossings), self.n_strands)
        return reduced.sign == 0

    def permutations(self, plot: bool = False) -> list[list[int]]:
        """Return the permutations induced by the braid"""
        perms = []
        strands = list(range(1, self.n_strands + 1))
        perms.append(strands.copy())
        if plot:
            print(" ".join(colorize(item) for item in strands))
        for gen in self.generators:
            i = abs(gen) - 1
            if gen > 0:  # Positive crossing (σ_i)
                if plot:
                    print(
                        " ".join(colorize(item) for item in strands[: i + 1])
                        + colorize(">", strands[i] - 1)
                        + " ".join(colorize(item) for item in strands[i + 1 :])
                    )
                strands[i], strands[i + 1] = strands[i + 1], strands[i]
            elif gen < 0:  # Negative crossing (σ_i⁻¹)
                if plot:
                    print(
                        " ".join(colorize(item) for item in strands[: i + 1])
                        + colorize("<", strands[i + 1] - 1)
                        + " ".join(colorize(item) for item in strands[i + 1 :])
                    )
                strands[i + 1], strands[i] = strands[i], strands[i + 1]

            elif plot:  # No crossing: the strands stay where they are
                print(" ".join(colorize(item) for item in strands))

            perms.append(strands.copy())
        if plot:
            print(" ".join(colorize(item) for item in strands))
        return perms

    def perm(self) -> list[int]:
        """Compute the permutation corresponding to the braid.

        This is a braid invariant.

        Returns:
            list[int]: The final permutation due to the braid.
        """
        return self.permutations()[-1]

    def is_pure(self) -> bool:
        """Check if a braid is pure (permutation is identity).

        Returns:
            bool: True if the braid is pure.
        """
        return self.perm() == list(range(1, self.n_strands + 1))

    def is_palindromic(self) -> bool:
        """Check if the braid word is palindromic.

        Returns:
            bool: True if the braid word reads the same forwards and backwards.
        """
        return self.generators == self.generators[::-1]

    def is_involutive(self) -> bool:
        """Check if braid word is involutive.

        Returns true if inverse of braid word is the same as braid word.
        This probably works only for the neutral element.

        Returns:
            bool: True if braid word is involutive.
        """
        return self.inverse().generators == self.generators

    def is_periodic(self) -> bool:
        """Check if braid is periodic.

        A braid x is periodic if and only if its nth power or its (n − 1)st power
        is a power of the half-twist ∆.

        https://hal.science/hal-00647035v2/file/B_nNTHClassificationv5.pdf
        Periodic braid are roots of ∆**m
        https://homepages.math.uic.edu/~jaca2009/notes/Meneses.pdf

        Returns:
            bool: True if the braid is periodic.
        """
        return (self ** (2 * self.n_strands)).perm() == list(
            range(1, self.n_strands + 1)
        ) or (self ** (2 * (self.n_strands - 1))).perm() == list(
            range(1, self.n_strands + 1)
        )

    def without_strand(self, strand: int) -> "Braid":
        """The braid with one strand taken out, as if it had never been there.

        The crossings that strand takes part in go with it; every other
        crossing stays, between the same two strands and the same way over,
        renumbered for the slot the strand no longer takes up.

        Args:
            strand: The strand to take out, numbered from 1 by where it
                starts, as :meth:`perm` numbers them.

        Returns:
            The braid on one strand fewer.

        Raises:
            ValueError: If there is no such strand, or none would be left.
        """
        n = self.n_strands
        if not 1 <= strand <= n:
            raise ValueError(f"No strand {strand}: the braid has strands 1 to {n}.")
        if n < 2:
            raise ValueError("Taking out its only strand leaves no braid.")
        history = self.slot_history()
        out = strand - 1
        kept: list[int] = []
        for before, generator in zip(history, self.generators, strict=False):
            if generator == 0:
                continue
            lower = abs(generator) - 1
            gone = before[out]
            if gone in (lower, lower + 1):
                continue
            moved = lower if lower < gone else lower - 1
            kept.append((moved + 1) * (1 if generator > 0 else -1))
        return Braid(kept, n - 1)

    def is_brunnian(self) -> bool:
        """Whether the braid is Brunnian: pure, and trivial once any one of
        its strands is taken out (:meth:`without_strand`), though perhaps
        not before — as three strands make the Borromean rings, any two of
        them apart.

        Brunnian braids form a subgroup of the pure braid group.  On three
        strands or more a braid trivial with any one strand out is pure
        anyway; on two, purity is what rules out a single crossing.  The
        trivial braid is Brunnian.

        https://en.wikipedia.org/wiki/Brunnian_link#Brunnian_braids

        Returns:
            bool: True if Brunnian.
        """
        if not self.is_pure():
            return False
        return all(
            self.without_strand(strand).is_trivial()
            for strand in range(1, self.n_strands + 1)
        )

    def is_reducible(self) -> bool:
        """Check if the braid is reducible.

        If a braid is reducible, it means that the strands can be separated
        into groups of strands (less groups than number of strands), such that
        each group is running inside one tube. The tubes themselves can form a braid.

        Returns:
            bool: True if reducible.
        """
        raise NotImplementedError()

    def slot_history(self) -> list[list[int]]:
        """Which slot every strand occupies, before and after each generator.

        Slots are the positions across the braid, numbered from zero.  A
        generator names two neighbouring slots and exchanges whoever is
        standing in them, whichever strands those happen to be, so this is
        the braid word's permutation unrolled step by step.

        It says nothing about which strand passed over which: that is the
        sign of the generator, and it is read separately — see
        :func:`~braidpy.parametric_strand.strand_paths`.

        Returns:
            A list of ``len(generators) + 1`` rows; row ``m`` holds the slot
            of each strand after ``m`` generators, indexed by strand.
        """
        n_strands = self.n_strands or max(abs(g) for g in self.generators) + 1
        slots = list(range(n_strands))
        history = [slots.copy()]

        for generator in self.generators:
            slots = slots.copy()
            if generator != 0:
                lower = abs(generator) - 1
                at_lower = slots.index(lower)
                at_upper = slots.index(lower + 1)
                slots[at_lower], slots[at_upper] = lower + 1, lower
            history.append(slots)

        return history

    def to_parametric_strands(self, amplitude: float = 0.2) -> list[ParametricStrand]:
        """Convert a braid into a list of 3D parametric strand paths.

        Args:
            amplitude: Height of the sine wave for over/under crossings.
                Defaults to 0.2.

        Returns:
            list[ParametricStrand]: List of ParametricStrand objects representing the strands.
        """
        # Read once: both are worked out afresh each time they are asked for.
        generators = self.generators
        history = self.slot_history()
        n_strands = self.n_strands or max(abs(g) for g in generators) + 1
        n_segments = len(generators) + 1

        strand_paths = [[row[strand] for row in history] for strand in range(n_strands)]

        # Generate arc sequences for each strand
        strand_arc_sequences: list[list[Arc]] = []
        for strand_id in range(n_strands):
            arcs: list[Arc] = []
            path = strand_paths[strand_id]

            for k in range(n_segments - 1):
                i0 = path[k]
                i1 = path[k + 1]
                x0 = i0 * amplitude
                x1 = i1 * amplitude
                # As fractions of the whole, not sums of steps: summed, the
                # last segment can stop short of 1 by a rounding error.
                t_start = k / n_segments
                t_end = (k + 1) / n_segments
                gen = generators[k]
                if i0 == i1 or gen == 0:
                    arc_func = make_idle_arc(x0, t_start, t_end)
                else:
                    i = abs(gen) - 1
                    over = (i0 == i and gen > 0) or (i0 == i + 1 and gen < 0)
                    arc_func = make_arc(
                        x0, x1, t_start, t_end, amplitude if over else -amplitude
                    )

                arcs.append((t_start, t_end, arc_func))

            # Final segment (idle)
            t_final_start = (n_segments - 1) / n_segments
            t_final_end = 1.0
            x_final = path[-1] * amplitude
            arcs.append(
                (
                    t_final_start,
                    t_final_end,
                    make_idle_arc(x_final, t_final_start, t_final_end),
                )
            )
            strand_arc_sequences.append(arcs)

        return [
            ParametricStrand(combine_arcs(strand)) for strand in strand_arc_sequences
        ]

    def draw(self) -> "Braid":
        """Draw the braid in the terminal with arrows.

        Allows to better check the different operations (with colors!).

        Returns:
            Braid: Returns self to allow chaining the different steps.
        """
        self.permutations(plot=True)
        # Return self to enable chaining the different steps
        return self

    def plot(
        self,
        n_samples: int = 400,
        line_width: float = 3.0,
        gap: float = 0.45,
        amplitude: float = 0.28,
        profile=None,
        color: Optional[str] = None,
        title: Optional[str] = None,
        save: Optional[str] = None,
        ax=None,
    ) -> "Braid":
        """Draw the braid as a 2D diagram, running down the page.

        The braid hangs downward, the way it is worked, with its word written
        above it.  Each strand is drawn in the colour :meth:`draw` gives it,
        and the one passing behind is interrupted where they meet.  The
        over-and-under is not re-derived: it is read from the curve
        :func:`~braidpy.parametric_strand.strand_paths` computes.

        This used to be drawn by braid-visualiser, which used its own
        colours, so a strand was one colour in the console and another in the
        plot.  The arguments changed with it: "style" is gone, "gap_size"
        became "gap" as a fraction of the strand spacing, and "save" takes a
        path rather than a flag.

        Args:
            n_samples: Points along each strand.
            line_width: Thickness of a strand.
            gap: Width of the break where a strand passes behind, as a
                fraction of the distance between neighbouring strands.
            amplitude: How far a strand swings out of line as it crosses.
            profile: How a strand travels sideways; smoothstep by default,
                :data:`~braidpy.parametric_strand.LINEAR` for straight
                segments.
            color: One colour for every strand; each takes its own by default.
            title: Heading; the braid's word by default, and "" for none.
            save: Path to write the figure to, if wanted.
            ax: Axes to draw on; a new figure otherwise.

        Returns:
            Braid: self, so the call can be chained.
        """
        from braidpy.braid_diagram import draw_diagram
        from braidpy.parametric_strand import SMOOTHSTEP

        draw_diagram(
            self,
            n_samples=n_samples,
            line_width=line_width,
            gap=gap,
            amplitude=amplitude,
            profile=SMOOTHSTEP if profile is None else profile,
            color=color,
            title=title,
            save=save,
            ax=ax,
        )
        return self


def slide_strand(n_slide: int, start_index: int = 1, sign: int = +1) -> Braid:
    """Combine Artin Generator to move one braid over or under several braids.

    This is noted as (ai...as) by Garside where i=start_index and s= i+n_slide.
    Πs corresponds to start_index=1 (default) and n_slide=s-1.

    Args:
        n_slide: Number of crossings.
        start_index: Index of the strand to move. Defaults to 1.
        sign: Positive if the start strand is going over. Defaults to +1.

    Returns:
        Braid: The corresponding braid.
    """
    b = Braid(0, n_strands=n_slide + start_index)
    for i in range(n_slide):
        b = b * Braid(sign * (start_index + i), n_strands=n_slide + start_index)
    return b.no_zero()


def weave_strand(n_slide: int, start_index: int = 1, sign: int = +1) -> Braid:
    """Combine Artin Generator to move one braid over/under/over... or under/over/under... several braids.

    Args:
        n_slide: Number of crossings.
        start_index: Index of the strand to move. Defaults to 1.
        sign: Positive if the start strand is first going over. Defaults to +1.

    Returns:
        Braid: The corresponding braid.
    """
    b = Braid(0, n_strands=n_slide + start_index)
    for i in range(n_slide):
        b = b * Braid(
            sign * (start_index + i) * (-1) ** i, n_strands=n_slide + start_index
        )
    return b.no_zero()
