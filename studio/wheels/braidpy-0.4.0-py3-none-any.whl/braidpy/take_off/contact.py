# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Contact between yarns sampled at common heights: which samples could
touch, the closest any two yarns come, how fast a braid must be drawn off
for its yarns to clear each other, and how tight they let it be drawn in."""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from .paths import StrandTrajectories

# How much faster than the least take-off that fits two yarns
# :func:`least_take_off` gives: a little, so that rounding cannot leave
# them touching after all.
_MARGIN = 1.01

# Every yarn is sampled at the same heights, so two samples can be closer than
# a diameter only if they are fewer than ``diameter / spacing`` levels apart.
# Comparing every yarn against every other at each such offset finds every
# close pair without a spatial index.


def _level_pairs(n_yarns: int, offset: int) -> tuple[np.ndarray, np.ndarray]:
    """Which yarns to compare with which, ``offset`` levels apart.

    Args:
        n_yarns: How many yarns.
        offset: How many levels apart the two samples compared are: the first
            yarn's at a level, the second's that many levels up.

    Returns:
        The two yarns of each pair, as two index arrays of the same length.
        At no offset each unordered pair comes once, a yarn never with
        itself; at any other, every ordered pair of different yarns, since
        which of the two is the higher then matters.
    """
    a, b = np.meshgrid(np.arange(n_yarns), np.arange(n_yarns), indexing="ij")
    keep = a < b if offset == 0 else a != b
    return a[keep], b[keep]


def _offsets(spacing: float, diameter: float, n: int) -> range:
    """How many levels apart two samples can be and still touch.

    Args:
        spacing: Height between two levels.
        diameter: Yarn diameter: samples further apart cannot touch.
        n: How many levels there are.

    Returns:
        The offsets, 0 up to fewer than ``diameter / spacing`` and fewer than
        ``n``; only 0 if the levels have no height between them.
    """
    if spacing <= 0:
        return range(1)
    return range(min(n, math.ceil(diameter / spacing)))


def _closest_approach(formed: np.ndarray, spacing: float) -> float:
    """The closest two different yarns come, between their samples.

    Args:
        formed: The yarns, ``(yarns, levels, 3)``, every yarn sampled at the
            same heights (:meth:`~braidpy.take_off.paths.YarnPaths.formed`).
        spacing: Height between two levels; offsets are only searched while
            their height alone is less than the closest found so far.

    Returns:
        The smallest distance between a sample of one yarn and a sample of
        another, at any levels; infinity for fewer than two yarns.
    """
    n_yarns, n, _ = formed.shape
    if n_yarns < 2:
        return math.inf
    best = math.inf
    offset = 0
    while offset < n and offset * spacing < best:
        a, b = _level_pairs(n_yarns, offset)
        diff = formed[a, : n - offset] - formed[b, offset:]
        best = min(best, float(np.sqrt(np.min(np.sum(diff**2, axis=-1)))))
        offset += 1
    return best


def least_take_off(
    trajectories: StrandTrajectories, yarn_diameter: float, take_off: float
) -> float:
    """The slowest take-off that lifts yarns passing the same point, or
    nearly, far enough apart to fit, at least ``take_off``.

    Where one strand leaves a place and another comes to the very same point
    later — as each crossing of a braid word does, one strand arriving where
    the other left — no drawing-in can separate them
    (:func:`jammed_contraction`): only the height the take-off puts between
    them can.  The fewer strands move at a time, the slower the default
    take-off, and the closer in height they come.

    Nearly the same point is as bad: two yarns a sideways distance ``s``
    apart touch, ``dz`` apart in height, unless the braid is drawn out by
    ``sqrt(d² − dz²) / s``, a hundredfold for carriers on one split axle
    that pass a hundredth of a diameter apart between two samples.  So the
    take-off is raised until every pair fits undrawn, ``dz`` at least
    ``sqrt(d² − s²)``; a braid whose yarns already do is left as it was.

    Args:
        trajectories: Where the strands went, sampled evenly in time.
        yarn_diameter: Yarn diameter.
        take_off: The take-off to start from.

    Returns:
        ``take_off``, or a little faster than the least take-off that lets
        the closest such pair fit.
    """
    center = np.asarray(trajectories.center(), dtype=float)
    rel = np.stack([xy - center for xy in trajectories.xy.values()])
    n_yarns, n, _ = rel.shape
    dt = float(trajectories.times[1] - trajectories.times[0])
    least = take_off
    for offset in _offsets(take_off * dt, yarn_diameter, n):
        if offset == 0:
            continue  # at the same time: no take-off can part them
        a, b = _level_pairs(n_yarns, offset)
        if len(a) == 0:
            break
        sideways = np.linalg.norm(rel[a, : n - offset] - rel[b, offset:], axis=-1)
        closest = float(np.min(sideways))
        if closest < yarn_diameter:
            room = math.sqrt(yarn_diameter**2 - closest**2)
            # Already that far apart in height: drawing in fits them.
            if offset * dt * take_off < room:
                least = max(least, _MARGIN * room / (offset * dt))
    return least


def jammed_contraction(rel: np.ndarray, spacing: float, diameter: float) -> float:
    """How far a braid can be drawn in before two yarns touch.

    Drawing the plane in by ``k`` shrinks the sideways part of every distance
    by ``k`` and leaves the height part alone, so a pair of samples a height
    ``dz`` apart and ``s`` apart sideways touches when
    ``k = sqrt(d² - dz²) / s``.  The braid jams at the largest of these — an
    exact answer over the samples, with no search.

    Args:
        rel: Per yarn, its samples relative to the axis; shape ``(yarns, n, 2)``,
            every yarn at the same heights.
        spacing: Height between successive samples.
        diameter: Yarn diameter.

    Returns:
        The contraction ``k``; above 1 if the yarns do not fit even undrawn.

    Raises:
        ValueError: If two yarns pass through the same place too close in
            height for any drawing-in to separate them — the take-off is too
            slow for yarns this thick.
    """
    if diameter <= 0:
        raise ValueError("yarn_diameter must be positive.")
    n_yarns, n, _ = rel.shape
    k = 0.0
    for offset in _offsets(spacing, diameter, n):
        a, b = _level_pairs(n_yarns, offset)
        if len(a) == 0:
            break
        room = diameter**2 - (offset * spacing) ** 2
        if offset * spacing >= diameter * (1 - 1e-9):
            # A diameter or more apart in height: they cannot touch.
            break
        sideways = np.linalg.norm(rel[a, : n - offset] - rel[b, offset:], axis=-1)
        if np.any(sideways == 0):
            raise ValueError(
                "Two yarns pass the same point too close together in height to "
                "be separated: increase take_off or reduce yarn_diameter."
            )
        k = max(k, float(np.sqrt(room) / np.min(sideways)))
    return k
